let para = document.getElementById("text");
let btn = document.getElementById("toggleBtn");

btn.onclick = function() {
  if (para.style.display === "none") {
    para.style.display = "block"; 
  } else {
    para.style.display = "none";  
  }
};
