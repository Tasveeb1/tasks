let arr = [15, 2, 88, 23, 45, 1, 99];
let max = arr[0];
let min = arr[0];
for (let num of arr) {
  if (num > max) max = num;
  if (num < min) min = num;
}
console.log("Maximum:", max);
console.log("Minimum:", min);
