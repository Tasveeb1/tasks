

let para = document.querySelector("p");
let style = document.createElement("style");
style.innerHTML = ".newStyle { color: red; font-weight: bold; background: yellow; }";
document.head.appendChild(style);
para.classList.add("newStyle");
