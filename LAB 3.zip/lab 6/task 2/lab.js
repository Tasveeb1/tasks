const Product = {
  id: 1,
  name: "Mobile Phone",
  price: 25000,
  inStock: true
};

console.log(Product);
