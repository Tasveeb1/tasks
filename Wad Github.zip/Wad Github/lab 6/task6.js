
let score = prompt("Enter student score (0 - 100):");
        score = Number(score);

        let grade;

        if (score >= 90) {
            grade = "A";
        } else if (score >= 80) {
            grade = "B";
        } else if (score >= 70) {
            grade = "C";
        } else if (score >= 60) {
            grade = "D";
        } else {
            grade = "F";
        }

        alert("Student Score: " + score + " → Grade: " + grade);
