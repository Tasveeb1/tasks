let numbers = [2, 4, 6, 8, 10];
numbers.forEach(function(num) {
  console.log("Square of", num, "is", num * num);
});
