
let bulb = document.getElementById("bulb");

bulb.onclick = function() {
  if (bulb.src.includes("light-bulb-1-1427502.jpg")) {
    bulb.src = "lab/light-bulb-on.jpg";     
  } else {
    bulb.src = "lab/light-bulb-1-1427502.jpg"; 
  }
}
