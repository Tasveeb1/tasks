const instagramProfile = {
  username: "tasveeb.fatima",
  displayName: "~nahhh",
  bio: "",
  posts: 0,
  followers: 142,
  following: 274,
  isPrivate: true,
  highlights: [
    { name: "🌄", description: "Nature/Scenery" },
    { name: "🫀", description: "Heart/Memories" },
    { name: "^_^", description: "Happy Moments" },
    { name: "💃", description: "Fashion or Poses" }
  ],

  links: {
    threads: "@tasveeb.fatima"
  }
};

console.log(instagramProfile);
