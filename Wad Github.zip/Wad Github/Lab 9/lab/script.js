
let paragraphs = document.querySelectorAll(".para");
paragraphs.forEach(p => {
  p.style.color = "red";
});

let paragraph = document.querySelector(".para");
paragraph.innerHTML = "This is <b>bold</b> text inside a paragraph.";


let p = document.querySelectorAll(".para")[1];
p.innerText = "This is new plain text without HTML tags.";

let items = document.querySelectorAll("li");
items.forEach(item => {
  item.innerText = item.innerText.toUpperCase();
});