
 let para = document.querySelector(".oldClass");
    console.log("Old Class:", para.className);
    para.className = "newClass";
    console.log("New Class:", para.className);


    let btn = document.createElement("button");
    btn.textContent = "Log In";
    btn.style.backgroundColor = "blue";
    btn.style.color = "white";
    document.documentElement.insertBefore(btn, document.body);



   