const toSeconds = (minutes) => {
  return minutes * 60;
};
console.log("5 minutes =", toSeconds(5), "seconds");
