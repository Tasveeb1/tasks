function countVowels(str) {
  let count = 0;
  for (let ch of str) {
    if ("aeiouAEIOU".includes(ch)) {
      count++;
    }
  }
  return count;
}
console.log(countVowels("Tasveeb Fatima")); 
