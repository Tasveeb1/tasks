let fruits = ["apple", "banana", "mango", "orange"];

console.log("Uppercase fruits:");
for (let fruit of fruits) {
  console.log(fruit.toUpperCase());
}
